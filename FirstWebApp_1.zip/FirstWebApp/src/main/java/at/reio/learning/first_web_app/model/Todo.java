/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package at.reio.learning.first_web_app.model;

import java.time.LocalDate;

/**
 *
 * @author reio
 */
public class Todo {
    
    private int id = 0;
    private final String user;
    
    private String description;
    private final LocalDate target;
    private boolean isDone = false;
    
   

    public Todo(int id, String user, String description, LocalDate target, boolean isDone) {
        this.id = id;
        this.user = user;
        this.description = description;
        this.target = target;
        this.isDone = isDone;
    }

    public boolean isIsDone() {
        return isDone;
    }

    public void setIsDone(boolean isDone) {
        this.isDone = isDone;
    }

    public int getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getTarget() {
        return target;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    

    @Override
    public String toString() {
        return "Todo{" + "id=" + id + ", user=" + user + ", description=" + description + ", target=" + target + ", isDone=" + isDone + '}';
    }
    
}
